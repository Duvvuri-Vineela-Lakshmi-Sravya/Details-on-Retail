/****** Finding how many orders were delivered in the specified month ******/



select c.cust_id,c.cust_id,o.ord_id,p.prod_id,ot.actual_dod,ot.tracking_id 
	from Orders o 
		join ord_products op 
			on o.ord_id=op.ord_id 
		join OrderTracking ot 
			on op.ord_prod_id=ot.ord_prd_id 
		join Customers c
			on o.cust_id=c.cust_id
		join Products p
			on p.prod_id=op.prod_id
		where MONTH(ot.actual_dod)=MONTH('2020-11-11')
		order by ot.actual_dod;