/***** Find the count of less, avg and high rating for each vendor *****/

/****1. Highest ****/
select v.vendor_id, v.vendor_name,count(op.rating) as High_Rating_Count
	from Vendors v
	join ord_products op
		on v.vendor_id=op.vendor_id
	where op.rating>=4
	group by v.vendor_id,v.vendor_name
	order by High_Rating_Count desc;

/*****2. Average ****/

select v.vendor_id, v.vendor_name,count(op.rating) as Average_Rating_Count
	from Vendors v
	join ord_products op
		on v.vendor_id=op.vendor_id
	where op.rating>=2 and op.rating<3
	group by v.vendor_id,v.vendor_name
	order by Average_Rating_Count desc;

/***** 3. Least*******/

select v.vendor_id, v.vendor_name,count(op.rating) as Less_Rating_Count
	from Vendors v
	join ord_products op
		on v.vendor_id=op.vendor_id
	where op.rating<2
	group by v.vendor_id,v.vendor_name

	order by Less_Rating_Count desc;