/***** Find the total orders that were placed under each product category *****/

select p.prod_category, count(o.ord_id) as Total_Orders from Orders o 
		join ord_products op
			on o.ord_id=op.ord_id
		join Products p
			on p.prod_id=op.prod_id
		group by p.prod_category
		order by Total_Orders desc;
