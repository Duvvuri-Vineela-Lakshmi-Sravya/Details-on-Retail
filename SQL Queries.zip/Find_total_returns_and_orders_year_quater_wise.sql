/***** Find total number of returns for each quater in every year ******/


select dt.year,dt.quater,count(r.return_id)as Total_Returns ,count(o.ord_id) as Total_Orders
	from returns r 
		right join ord_products op 
			on r.return_id=op.return_id
		join Orders o 
			on o.ord_id=op.ord_id 
		join Date_tbl dt 
			on dt.Date=o.ord_dt
   group by dt.year,dt.quater
   order by dt.year desc,dt.quater asc;

