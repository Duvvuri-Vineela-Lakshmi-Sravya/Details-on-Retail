/***** Finding the total number of products each and every vendor is selling *******/

select v.vendor_id,v.vendor_name, count(op.prod_id) as Total_Products from Vendors v 
	join ord_products op
		on v.vendor_id=op.vendor_id
	group by v.vendor_id,v.vendor_name
	order by Total_Products DESC;
