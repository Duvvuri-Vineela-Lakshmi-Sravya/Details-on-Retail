/*** Find the total number of orders StatesWise  *****/

select a.state,count(o.ord_id) as Total_Orders from Orders o 
		join Customers c
			on c.cust_id=o.cust_id
		join Address a 
		on c.cust_id=a.cust_id
	group by a.state
	order by Total_Orders desc;

