/****Check the number of orders placed gender wise ******/

select c.gender ,count(o.ord_id) as Total_Orders_Count
	from Customers c 
		join Orders o
			on c.cust_id=o.cust_id
	group by c.gender
	order by Total_Orders_Count desc;
