/***** Find the count of less, avg and high rating for each vendor *****/

select v.vendor_id, sum(case when op.rating<=2 then 1 else 0 end) as Less_Rating_Count, 
								  sum(case when op.rating>2 AND op.rating<=3 then 1 else 0 end) as Avg_Rating_Count,
								  sum(case when op.rating>3 then 1 else 0 end) as High_Rating_Count
	from Vendors v
	join ord_products op
		on v.vendor_id=op.vendor_id
	group by v.vendor_id
	order by v.vendor_id;
