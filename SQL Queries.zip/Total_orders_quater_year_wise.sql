/***** Find total number of orders for each quater in every year ******/

select dt.year,dt.quater,count(o.ord_id) as Total_Orders from Orders o
		join Date_tbl dt 
			on dt.Date=o.ord_dt
		group by dt.year,dt.quater
		order by dt.year desc,dt.quater;


